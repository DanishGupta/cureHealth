package com.example.curehealth;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;

public class Main14Activity extends AppCompatActivity {
String TAG="wet";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main14);
        Log.e(TAG, "onCreate: " );
    }
}
