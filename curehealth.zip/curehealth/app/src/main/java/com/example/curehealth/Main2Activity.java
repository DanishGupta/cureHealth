package com.example.curehealth;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class Main2Activity extends AppCompatActivity {

    Button btn2,btn3,btn4,btn5,btn6,btn7,btn8,btn9,btn10,btn11,btn12,btn13,btn14,btn15,btn16,btn17,btn18,btn19,btn20,btn21,btn22,btn23,btn24,btn25,btn26,btn27,btn28,btn29,btn30,btn31,btn33,btn34,btn35,btn36,btn37,btn38,btn39,btn40,btn41,btn42;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);
        btn2=(Button) findViewById(R.id.button2);
        btn3=(Button) findViewById(R.id.button3);
        btn4=(Button) findViewById(R.id.button4);
        btn5=(Button) findViewById(R.id.button5);
        btn6=(Button) findViewById(R.id.button6);
        btn7=(Button) findViewById(R.id.button7);
        btn8=(Button) findViewById(R.id.button8);
        btn9=(Button) findViewById(R.id.button9);
        btn10=(Button) findViewById(R.id.button10);
        btn11=(Button) findViewById(R.id.button11);
        btn12=(Button) findViewById(R.id.button12);
        btn13=(Button) findViewById(R.id.button13);
        btn14=(Button) findViewById(R.id.button14);
        btn15=(Button) findViewById(R.id.button15);
        btn16=(Button) findViewById(R.id.button16);
        btn17=(Button) findViewById(R.id.button17);
        btn18=(Button) findViewById(R.id.button18);
        btn19=(Button) findViewById(R.id.button19);
        btn20=(Button) findViewById(R.id.button20);
        btn21=(Button) findViewById(R.id.button21);
        btn22=(Button) findViewById(R.id.button22);
        btn23=(Button) findViewById(R.id.button23);
        btn24=(Button) findViewById(R.id.button24);
        btn25=(Button) findViewById(R.id.button25);
        btn26=(Button) findViewById(R.id.button26);
        btn27=(Button) findViewById(R.id.button27);
        btn28=(Button) findViewById(R.id.button28);
        btn29=(Button) findViewById(R.id.button29);
        btn30=(Button) findViewById(R.id.button30);
        btn31=(Button) findViewById(R.id.button31);

        btn33=(Button) findViewById(R.id.button33);
        btn34=(Button) findViewById(R.id.button34);
        btn35=(Button) findViewById(R.id.button35);
        btn36=(Button) findViewById(R.id.button36);
        btn37=(Button) findViewById(R.id.button37);
        btn38=(Button) findViewById(R.id.button38);
        btn39=(Button) findViewById(R.id.button39);
        btn40=(Button) findViewById(R.id.button40);
        btn41=(Button) findViewById(R.id.button41);
        btn42=(Button) findViewById(R.id.button42);
        btn2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i2=new Intent(getApplicationContext(),Main4Activity.class);
                startActivity(i2);
            }
        });
        btn3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i3=new Intent(getApplicationContext(),Main5Activity.class);
                startActivity(i3);
            }
        });
        btn4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i4=new Intent(getApplicationContext(),Main6Activity.class);
                startActivity(i4);
            }
        });
        btn5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i5=new Intent(getApplicationContext(),Main7Activity.class);
                startActivity(i5);
            }
        });
        btn6.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i6=new Intent(getApplicationContext(),Main8Activity.class);
                startActivity(i6);
            }
        });
        btn7.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i7=new Intent(getApplicationContext(),Main9Activity.class);
                startActivity(i7);
            }
        });
        btn8.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i8=new Intent(getApplicationContext(),Main10Activity.class);
                startActivity(i8);
            }
        });
        btn9.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i9=new Intent(getApplicationContext(),Main11Activity.class);
                startActivity(i9);
            }
        });
        btn10.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i10=new Intent(getApplicationContext(),Main12Activity.class);
                startActivity(i10);
            }
        });
        btn11.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i11=new Intent(getApplicationContext(),Main13Activity.class);
                startActivity(i11);
            }
        });
        btn12.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i12=new Intent(getApplicationContext(),Main14Activity.class);
                startActivity(i12);
            }
        });
        btn13.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i13=new Intent(getApplicationContext(),Main15Activity.class);
                startActivity(i13);
            }
        });
        btn14.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i14=new Intent(getApplicationContext(),Main16Activity.class);
                startActivity(i14);
            }
        });
        btn15.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i15=new Intent(getApplicationContext(),Main17Activity.class);
                startActivity(i15);
            }
        });
        btn16.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i6=new Intent(getApplicationContext(),Main18Activity.class);
                startActivity(i6);
            }
        });
        btn17.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i17=new Intent(getApplicationContext(),Main19Activity.class);
                startActivity(i17);
            }
        });
        btn18.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i18=new Intent(getApplicationContext(),Main20Activity.class);
                startActivity(i18);
            }
        });
        btn19.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i19=new Intent(getApplicationContext(),Main21Activity.class);
                startActivity(i19);
            }
        });
        btn20.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i20=new Intent(getApplicationContext(),Main22Activity.class);
                startActivity(i20);
            }
        });
        btn21.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i21=new Intent(getApplicationContext(),Main23Activity.class);
                startActivity(i21);
            }
        });
        btn22.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i22=new Intent(getApplicationContext(),Main24Activity.class);
                startActivity(i22);
            }
        });
        btn23.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i23=new Intent(getApplicationContext(),Main25Activity.class);
                startActivity(i23);
            }
        });
        btn24.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i24=new Intent(getApplicationContext(),Main26Activity.class);
                startActivity(i24);
            }
        });
        btn25.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i25=new Intent(getApplicationContext(),Main27Activity.class);
                startActivity(i25);
            }
        });
        btn26.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i26=new Intent(getApplicationContext(),Main28Activity.class);
                startActivity(i26);
            }
        });
        btn27.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i27=new Intent(getApplicationContext(),Main29Activity.class);
                startActivity(i27);
            }
        });
        btn28.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i28=new Intent(getApplicationContext(),Main30Activity.class);
                startActivity(i28);
            }
        });
        btn29.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i29=new Intent(getApplicationContext(),Main31Activity.class);
                startActivity(i29);
            }
        });
        btn30.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i30=new Intent(getApplicationContext(),Main32Activity.class);
                startActivity(i30);
            }
        });
        btn31.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i31=new Intent(getApplicationContext(),Main33Activity.class);
                startActivity(i31);
            }
        });

        btn33.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i33=new Intent(getApplicationContext(),Main34Activity.class);
                startActivity(i33);
            }
        });
        btn34.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i34=new Intent(getApplicationContext(),Main35Activity.class);
                startActivity(i34);
            }
        });
        btn35.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i35=new Intent(getApplicationContext(),Main36Activity.class);
                startActivity(i35);
            }
        });
        btn36.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i36=new Intent(getApplicationContext(),Main37Activity.class);
                startActivity(i36);
            }
        });
        btn37.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i37=new Intent(getApplicationContext(),Main38Activity.class);
                startActivity(i37);
            }
        });
        btn38.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i38=new Intent(getApplicationContext(),Main39Activity.class);
                startActivity(i38);
            }
        });
        btn39.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i39=new Intent(getApplicationContext(),Main40Activity.class);
                startActivity(i39);
            }
        });
        btn40.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i40=new Intent(getApplicationContext(),Main41Activity.class);
                startActivity(i40);
            }
        });
        btn41.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i41=new Intent(getApplicationContext(),Main42Activity.class);
                startActivity(i41);
            }
        });
        btn42.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i42=new Intent(getApplicationContext(),Main43Activity.class);
                startActivity(i42);
            }
        });
    }
}
