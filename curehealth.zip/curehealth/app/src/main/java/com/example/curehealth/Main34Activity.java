package com.example.curehealth;

import android.os.Bundle;
import android.app.Activity;

public class Main34Activity extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main34);
    }

}
