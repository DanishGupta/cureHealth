package com.example.curehealth;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseAuth;

public class register extends AppCompatActivity {
//    EditText edm  ;
//    FirebaseAuth mAuth;
//    String codeSent;
private Spinner spinner;
    private EditText editText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);
        spinner = findViewById(R.id.spinnerCountries);
        spinner.setAdapter(new ArrayAdapter<String>(this, android.R.layout.simple_spinner_dropdown_item, CountryData.countryNames));

        editText = findViewById(R.id.editTextPhone);
        findViewById(R.id.buttonContinue).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String code = CountryData.countryAreaCodes[spinner.getSelectedItemPosition()];

                String number = editText.getText().toString().trim();

                if (number.isEmpty() || number.length() < 10) {
                    editText.setError("Valid number is required");
                    editText.requestFocus();
                    return;
                }

                String phoneNumber = "+" + code + number;

                Intent intent = new Intent(register.this, register2.class);
                intent.putExtra("phonenumber", phoneNumber);
                startActivity(intent);
                Toast.makeText(register.this, "sent", Toast.LENGTH_SHORT).show();

            }
        });
    }

    @Override
    protected void onStart() {
        super.onStart();

        if (FirebaseAuth.getInstance().getCurrentUser() != null) {
            Intent intent = new Intent(this, welcome.class);
            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);

            startActivity(intent);
        }

    }}
//        mAuth= FirebaseAuth.getInstance();
//
//        edm=findViewById(R.id.edm);
//        findViewById(R.id.getcode).setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//                sendVerificationCode();
//            }
//
//        });
//    }
//    private void sendVerificationCode() {
//
//        String phone = edm.getText().toString();
//
//        if(phone.isEmpty()){
//            edm.setError("error");
//            //ed1.requestFocus();
//            return;
//        }
//        if(phone.length()<10){
//            edm.setError("error");
//            //ed1.requestFocus();
//            return;
//        }
//        PhoneAuthProvider.getInstance().verifyPhoneNumber(
//               "+91"+ phone,        // Phone number to verify
//                60,                 // Timeout duration
//                TimeUnit.SECONDS,   // Unit of timeout
//                this,               // Activity (for callback binding)
//                mCallbacks);        // OnVerificationStateChangedCallbacks
//
//        Toast.makeText(this, "send", Toast.LENGTH_SHORT).show();
//        Intent i=new Intent(this,welcome.class);
//        startActivity(i);
//    }
//    PhoneAuthProvider.OnVerificationStateChangedCallbacks mCallbacks=new PhoneAuthProvider.OnVerificationStateChangedCallbacks() {
//
//        @Override
//        public void onVerificationCompleted(PhoneAuthCredential phoneAuthCredential) {
//
//        }
//
//        @Override
//        public void onVerificationFailed(FirebaseException e) {
//        }
//
//        @Override
//        public void onCodeSent(String s, PhoneAuthProvider.ForceResendingToken forceResendingToken) {
//            super.onCodeSent(s, forceResendingToken);
//
//            codeSent=s;
//            //Toast.makeText(MainActivity.this, "edsss", Toast.LENGTH_SHORT).show();
//        }
//    };
//}
