package com.example.curehealth;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class Main3Activity extends AppCompatActivity {
    Button btn43,btn44,btn45,btn46,btn47,btn48,btn49,btn50,btn51,btn52,btn53,btn54,btn55,btn56,btn57,btn58,btn59,btn60,btn61,btn62,btn63,btn64,btn65,btn66,btn67,btn68,btn69,btn70,btn71,btn72,btn73,btn74,btn75,btn76,btn77,btn78,btn79,btn80,btn81,btn82;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main3);
        btn43=(Button) findViewById(R.id.button43);
        btn44=(Button) findViewById(R.id.button44);
        btn45=(Button) findViewById(R.id.button45);
        btn46=(Button) findViewById(R.id.button46);
        btn47=(Button) findViewById(R.id.button47);
        btn48=(Button) findViewById(R.id.button48);
        btn49=(Button) findViewById(R.id.button49);
        btn50=(Button) findViewById(R.id.button50);
        btn51=(Button) findViewById(R.id.button51);
        btn52=(Button) findViewById(R.id.button52);
        btn53=(Button) findViewById(R.id.button53);
        btn54=(Button) findViewById(R.id.button54);
        btn55=(Button) findViewById(R.id.button55);
        btn56=(Button) findViewById(R.id.button56);
        btn57=(Button) findViewById(R.id.button57);
        btn58=(Button) findViewById(R.id.button58);
        btn59=(Button) findViewById(R.id.button59);
        btn60=(Button) findViewById(R.id.button60);
        btn61=(Button) findViewById(R.id.button61);
        btn62=(Button) findViewById(R.id.button62);
        btn63=(Button) findViewById(R.id.button63);
        btn64=(Button) findViewById(R.id.button64);
        btn65=(Button) findViewById(R.id.button65);
        btn66=(Button) findViewById(R.id.button66);
        btn67=(Button) findViewById(R.id.button67);
        btn68=(Button) findViewById(R.id.button68);
        btn69=(Button) findViewById(R.id.button69);
        btn70=(Button) findViewById(R.id.button70);
        btn71=(Button) findViewById(R.id.button71);
        btn72=(Button) findViewById(R.id.button72);
        btn73=(Button) findViewById(R.id.button73);
        btn74=(Button) findViewById(R.id.button74);
        btn75=(Button) findViewById(R.id.button75);
        btn76=(Button) findViewById(R.id.button76);
        btn77=(Button) findViewById(R.id.button77);
        btn78=(Button) findViewById(R.id.button78);
        btn79=(Button) findViewById(R.id.button79);
        btn80=(Button) findViewById(R.id.button80);
        btn81=(Button) findViewById(R.id.button81);
        btn82=(Button) findViewById(R.id.button82);

        btn43.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i2=new Intent(getApplicationContext(),Main45Activity.class);
                startActivity(i2);
            }
        });
        btn44.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i3=new Intent(getApplicationContext(),Main46Activity.class);
                startActivity(i3);
            }
        });
        btn45.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i4=new Intent(getApplicationContext(),Main47Activity.class);
                startActivity(i4);
            }
        });
        btn46.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i5=new Intent(getApplicationContext(),Main48Activity.class);
                startActivity(i5);
            }
        });
        btn47.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i6=new Intent(getApplicationContext(),Main49Activity.class);
                startActivity(i6);
            }
        });
        btn48.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i7=new Intent(getApplicationContext(),Main50Activity.class);
                startActivity(i7);
            }
        });
        btn49.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i8=new Intent(getApplicationContext(),Main51Activity.class);
                startActivity(i8);
            }
        });
        btn50.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i9=new Intent(getApplicationContext(),Main52Activity.class);
                startActivity(i9);
            }
        });
        btn51.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i10=new Intent(getApplicationContext(),Main53Activity.class);
                startActivity(i10);
            }
        });
        btn52.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i11=new Intent(getApplicationContext(),Main54Activity.class);
                startActivity(i11);
            }
        });
        btn53.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i12=new Intent(getApplicationContext(),Main55Activity.class);
                startActivity(i12);
            }
        });
        btn54.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i13=new Intent(getApplicationContext(),Main56Activity.class);
                startActivity(i13);
            }
        });
        btn55.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i14=new Intent(getApplicationContext(),Main57Activity.class);
                startActivity(i14);
            }
        });
        btn56.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i15=new Intent(getApplicationContext(),Main58Activity.class);
                startActivity(i15);
            }
        });
        btn57.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i6=new Intent(getApplicationContext(),Main59Activity.class);
                startActivity(i6);
            }
        });
        btn58.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i17=new Intent(getApplicationContext(),Main60Activity.class);
                startActivity(i17);
            }
        });
        btn59.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i18=new Intent(getApplicationContext(),Main61Activity.class);
                startActivity(i18);
            }
        });
        btn60.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i19=new Intent(getApplicationContext(),Main62Activity.class);
                startActivity(i19);
            }
        });
        btn61.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i20=new Intent(getApplicationContext(),Main63Activity.class);
                startActivity(i20);
            }
        });
        btn62.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i21=new Intent(getApplicationContext(),Main64Activity.class);
                startActivity(i21);
            }
        });
        btn63.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i22=new Intent(getApplicationContext(),Main65Activity.class);
                startActivity(i22);
            }
        });
        btn64.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i23=new Intent(getApplicationContext(),Main66Activity.class);
                startActivity(i23);
            }
        });
        btn65.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i24=new Intent(getApplicationContext(),Main67Activity.class);
                startActivity(i24);
            }
        });
        btn66.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i25=new Intent(getApplicationContext(),Main68Activity.class);
                startActivity(i25);
            }
        });
        btn67.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i26=new Intent(getApplicationContext(),Main69Activity.class);
                startActivity(i26);
            }
        });
        btn68.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i27=new Intent(getApplicationContext(),Main70Activity.class);
                startActivity(i27);
            }
        });
        btn69.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i28=new Intent(getApplicationContext(),Main71Activity.class);
                startActivity(i28);
            }
        });
        btn70.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i29=new Intent(getApplicationContext(),Main72Activity.class);
                startActivity(i29);
            }
        });
        btn71.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i30=new Intent(getApplicationContext(),Main73Activity.class);
                startActivity(i30);
            }
        });
        btn72.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i31=new Intent(getApplicationContext(),Main74Activity.class);
                startActivity(i31);
            }
        });
        btn73.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i32=new Intent(getApplicationContext(),Main75Activity.class);
                startActivity(i32);
            }
        });
        btn74.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i33=new Intent(getApplicationContext(),Main76Activity.class);
                startActivity(i33);
            }
        });
        btn75.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i34=new Intent(getApplicationContext(),Main77Activity.class);
                startActivity(i34);
            }
        });
        btn76.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i35=new Intent(getApplicationContext(),Main78Activity.class);
                startActivity(i35);
            }
        });
        btn77.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i36=new Intent(getApplicationContext(),Main79Activity.class);
                startActivity(i36);
            }
        });
        btn78.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i37=new Intent(getApplicationContext(),Main80Activity.class);
                startActivity(i37);
            }
        });
        btn79.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i38=new Intent(getApplicationContext(),Main81Activity.class);
                startActivity(i38);
            }
        });
        btn80.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i39=new Intent(getApplicationContext(),Main82Activity.class);
                startActivity(i39);
            }
        });
        btn81.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i40=new Intent(getApplicationContext(),Main83Activity.class);
                startActivity(i40);
            }
        });
        btn82.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i41=new Intent(getApplicationContext(),Main84Activity.class);
                startActivity(i41);
            }
        });

    }
}
